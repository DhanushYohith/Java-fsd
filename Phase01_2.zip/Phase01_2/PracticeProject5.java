package assistedPractice.week1_2;

//Demonstrate throw , throws , finally and Custom exceptions in Java .
@SuppressWarnings("serial")
class CustomException extends Exception{
	
	public CustomException(String msg) {
		super(msg) ;
	}
	
}


public class PracticeProject5 {
	
	public static void main (String[] args) {
		try
		{
			validate(15) ;
		}
		catch(CustomException e) 
		{
			System.out.println("CustomException CaUght ..."+e.getMessage()) ;			
		}
		finally 
		{
			System.out.println("Finally Block Executed...");			
		}	
	}
	
	public static void validate(int age) throws CustomException{
		if (age <18)
			throw new CustomException("Age is less than 18..");
		else
			System.out.println("Age is Valid..");
	}	
}

package assistedPractice.week1;

public class PracticeProject4 {
	private int age ;
	private String name;
	
	// Constructors:  1)Default  2)Parameterized
	//Constructor Overloading 
	
	public PracticeProject4() {
		//Default Constructor
	}
	
	public PracticeProject4(int age , String name) {
		this.age = age;           // Parameterized Constructor
		this.name = name;
	}
	
	public static void main(String[] args) {
		
		PracticeProject4 obj1 = new PracticeProject4();
		PracticeProject4 obj2 = new PracticeProject4(4,"abc");
		
		System.out.println(obj1.name+" "+obj1.age);
		System.out.println(obj2.name+" "+obj2.age);
	}
	
}

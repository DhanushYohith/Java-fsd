package assistedPractice.week1_2;

class SleepDemo extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Sleeping thread: " + i);
            try {
                Thread.sleep(1000); // Sleep for 1 second
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}

class WaitDemo extends Thread {
    public void run() {
        synchronized (this) {
            System.out.println("Waiting thread started");
            try {
                wait(5000); // Wait for 5 seconds
            } catch (InterruptedException e) {
                System.out.println(e);
            }
            System.out.println("Waiting thread finished");
        }
    }
}

public class PracticeProject2 {
    public static void main(String[] args) {
        // Demonstrate sleep()
        SleepDemo sleepThread = new SleepDemo();
        sleepThread.start();

        // Demonstrate wait()
        WaitDemo waitThread = new WaitDemo();
        waitThread.start();
    }
}
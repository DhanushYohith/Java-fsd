package assistedPractice.week1_2;

//Demonstrating try and Catch ...

public class PracticeProject4 {
	
	public static void main (String[] args) {
		
		try 
		{
			int[] numbers = {1 , 2 , 3} ;
			System.out.println(numbers[4]) ;//Out of bounds Index 			
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Exception CAught: "+e);
		}

	}		
		
}

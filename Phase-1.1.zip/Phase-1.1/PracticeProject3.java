package assistedPractice.week1_2;

class Counter {
    private int count = 0;

    // Synchronized method to increment count
    public synchronized void increment() {
        count++;
    }

    public int getCount() {
        return count;
    }
}

class Worker extends Thread {
    private Counter counter;

    public Worker(Counter counter) {
        this.counter = counter;
    }

    public void run() {
        for (int i = 0; i < 1000; i++) {
            counter.increment();
        }
    }
}

public class PracticeProject3 {
    public static void main(String[] args) {
        Counter counter = new Counter();
        Worker[] workers = new Worker[5];

        for (int i = 0; i < workers.length; i++) {
            workers[i] = new Worker(counter);
            workers[i].start();
        }

        // Wait for all threads to finish
        for (Worker worker : workers) {
            try {
                worker.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Final count: " + counter.getCount());
    }
}

package assistedPractice.week2_2;

public class PracticeProject1 {

	
	// unary Search 
	
	public static int linearSearch(int[] arr , int target)
	{
		for(int i=0 ; i<arr.length ; i++) {
			if(arr[i] == target)
				return i ;	 // returns the index position at which the element is present..
		}
		return -1 ;			
	}
	
	public static void main(String[] args) 
	{
		int[] arr = {2,45,6,3,4,8,1} ;
		int target = 45 ;
		
		int index = linearSearch(arr , target) ;
		
		if(index != -1)
			System.out.println("Element "+target+" found at index : "+index);	
		
		else
			System.out.println("Element " + target + " not found in the array.." );
		
		
	}
	
		
}

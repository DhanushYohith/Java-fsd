package assistedPractice.week2;

import java.util.LinkedList;
import java.util.Queue;

 // QUEUE -- Program to insert and remove elements in a queue..


public class PracticeProject9 {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        
        enqueue(queue, 10);
        enqueue(queue, 20);
        enqueue(queue, 30);
        enqueue(queue, 40);
        enqueue(queue, 50);

        
        displayQueue(queue);

        
        dequeue(queue);
        dequeue(queue);

        
        displayQueue(queue);
    }

    
    public static void enqueue(Queue<Integer> queue, int element) {
        queue.add(element);
        System.out.println("Enqueued element: " + element);
    }

    
    public static void dequeue(Queue<Integer> queue) {
        if (!queue.isEmpty()) {
            int removedElement = queue.remove();
            System.out.println("Dequeued element: " + removedElement);
        } else {
            System.out.println("Queue is empty. Cannot dequeue.");
        }
    }

    
    public static void displayQueue(Queue<Integer> queue) {
        System.out.println("Elements in the queue:");
        for (Integer element : queue) {
            System.out.println(element);
        }
    }
}

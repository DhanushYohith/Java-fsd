package assistedPractice.week2;

// Sum of n number of elements from ranging from L to R

import java.util.Scanner ;

public class PracticeProject3 {
	
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements (n): ");
        int n = scanner.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        System.out.print("Enter the range (L and R): ");
        int L = scanner.nextInt();
        int R = scanner.nextInt();

        int sum = calculateSumInRange(arr, L, R);
        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);

        scanner.close();
    }

    public static int calculateSumInRange(int[] arr, int L, int R) {
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }
        return sum;
    }
}

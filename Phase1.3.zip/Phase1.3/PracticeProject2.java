package assistedPractice.week2;


// Program to find the 4th smallest element in an Unsorted list.. 

import java.util.Arrays ;

public class PracticeProject2 {
	
    public static void main(String[] args) {
        int[] arr = {23,45,22,11,67,35,24,38}; 
        int k = 4;

        int fourthSmallest = findKthSmallest(arr, k);
        
        System.out.println("The " + k + "th smallest element is: " + fourthSmallest);
    }

    public static int findKthSmallest(int[] arr, int k)
    {
        Arrays.sort(arr);         
        return arr[k - 1];
    }

}

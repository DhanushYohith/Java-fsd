package assistedPractice.week2;


//Inserting a new element in a sorted circular linked list..

class Node1 {
    int data;
    Node next;

    public Node1(int data) {
        this.data = data;
        this.next = null;
    }
}

public class PracticeProject6 {
    Node head;

    public void insert(int newData) {
        Node newNode = new Node(newData);
        Node current = head;

        if (current == null) { 
            newNode.next = newNode;
            head = newNode;
        } else if (current.data >= newNode.data) { 
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            head = newNode;
        } else { 
            while (current.next != head && current.next.data < newNode.data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    public void printList() {
        Node current = head;
        if (head != null) {
            do {
                System.out.print(current.data + " ");
                current = current.next;
            } while (current != head);
            System.out.println();
        }
    }

    public static void main(String[] args) {
       PracticeProject6 list = new PracticeProject6();
        list.insert(2);
        list.insert(5);
        list.insert(7);
        list.insert(10);
        list.insert(1);
        list.insert(3);

        System.out.println("Sorted Circular Linked List:");
        list.printList();
    }
}
